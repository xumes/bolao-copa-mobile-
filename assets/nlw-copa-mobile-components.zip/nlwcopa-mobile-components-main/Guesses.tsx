import { Box } from 'native-base';

interface Props {
  poolId: string;
}

export function Guesses({ poolId }: Props) {

  return (
    <Box>

    </Box>
  );
}
